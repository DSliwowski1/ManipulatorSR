/*
 * results.h
 *
 *  Created on: May 31, 2020
 *      Author: Patryk
 */

#ifndef INC_RESULTS_H_
#define INC_RESULTS_H_


void calcU(float u[], float invG[], float F[], float v[]);



#endif /* INC_RESULTS_H_ */
